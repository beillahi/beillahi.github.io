/*

   Ce programme pour l' exercice 1 question 1

*/

public class Exercice1_Question1 {
    








    // Le point d'entrée du programme.
    // pour testing la réponse
    public static void main (String[] args) {
	
    }


}

/*

   Ce programme est pour l' exercice 2 question 3

*/

public class Exercice2_Question3 {
    








    // Le point d'entrée du programme.
    // pour tester la réponse
    public static void main (String[] args) {
	
    }


}

/*

   Ce programme est pour l' exercice 1 question 2

*/

public class Exercice1_Question2 {
    








    // Le point d'entrée du programme.
    // pour tester la réponse
    public static void main (String[] args) {
	
    }


}

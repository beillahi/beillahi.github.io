/*

   Ce programme est pour l' exercice 2 question 2

*/

public class Exercice2_Question2 {
    








    // Le point d'entrée du programme.
    // pour tester la réponse
    public static void main (String[] args) {
	
    }


}

/*

   Ce programme est pour l' exercice 1 question 3

*/

public class Exercice1_Question3 {
    








    // Le point d'entrée du programme.
    // pour tester la réponse
    public static void main (String[] args) {
	
    }


}
